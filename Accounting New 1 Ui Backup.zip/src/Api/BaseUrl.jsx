// const BaseUrl = 'https://accounting-prisma-production.up.railway.app/api/v1/';

const BaseUrl = 'https://02x4fc84-8080.inc1.devtunnels.ms/api/v1/';

// const BaseUrl = 'https://02x4fc84-8080.inc1.devtunnels.ms/api/v1/';

export default BaseUrl;