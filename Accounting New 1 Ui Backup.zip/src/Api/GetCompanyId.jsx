
const GetCompanyId = () => {
  return localStorage.getItem("CompanyId"); 
};
export default GetCompanyId;








